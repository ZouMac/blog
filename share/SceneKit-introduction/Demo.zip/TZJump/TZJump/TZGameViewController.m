//
//  TZGameViewController.m
//  TZJump
//
//  Created by tanzou on 2017/10/10.
//  Copyright © 2017年 tanzou. All rights reserved.
//

#import "TZGameViewController.h"

typedef enum : NSUInteger {
    CollisionDetectionMaskBall = 1,
    CollisionDetectionMaskBox1 = 2,
    CollisionDetectionMaskBox2 = 3,
    CollisionDetectionMaskBox3 = 4,
} CollisionDetectionMask;


@interface TZGameViewController ()<SCNPhysicsContactDelegate>
@property (nonatomic, strong) NSTimer *timer;

@property (nonatomic, strong) SCNScene *scene;

@property (nonatomic, strong) SCNNode *cameraNode;

@property (nonatomic, strong) SCNNode *lightNode;

@property (nonatomic, strong) SCNNode *ballNode;

@property (nonatomic, strong) SCNNode *boxNode1;

@property (nonatomic, strong) SCNNode *boxNode2;

@property (nonatomic, strong) SCNNode *boxNode3;

@property (strong, nonatomic) UILabel *failLabel;

@property (strong, nonatomic) UILabel *scoreLabel;

@end

@implementation TZGameViewController

-(UILabel *)scoreLabel
{
    if (_scoreLabel == nil) {
        _scoreLabel = [[UILabel alloc] init];
        _scoreLabel.font = [UIFont systemFontOfSize:30];
        _scoreLabel.frame = CGRectMake(300, 250, 90, 40);
        _scoreLabel.backgroundColor = [UIColor clearColor];
        _scoreLabel.textColor = [UIColor orangeColor];
        [self.view addSubview:_scoreLabel];
    }
    return _scoreLabel;
}
-(UILabel *)failLabel
{
    if (_failLabel == nil) {
        _failLabel = [[UILabel alloc] init];
        _failLabel.text = @"死掉了。。。";
        _failLabel.font = [UIFont systemFontOfSize:40];
        _failLabel.frame = CGRectMake(100, 300, self.view.bounds.size.width - 100, self.view.bounds.size.width - 100);
        _failLabel.hidden = YES;
        _failLabel.backgroundColor = [UIColor clearColor];
        _failLabel.textColor = [UIColor redColor];
        [self.view addSubview:_failLabel];
    }
    return _failLabel;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self createNode];
    
}

- (void)createNode{
    SCNScene *scene = [SCNScene scene];
    self.scene = scene;
    
    SCNSphere *ball = [SCNSphere sphereWithRadius:4];
    
    SCNNode *ballNode = [SCNNode nodeWithGeometry:ball];
    ballNode.geometry.firstMaterial.diffuse.contents = [UIColor colorWithRed:0.6 green:0.8 blue:0.4 alpha:1];
    ballNode.position = SCNVector3Make(0, 12, -16);
    [scene.rootNode addChildNode:ballNode];
    ballNode.physicsBody = [SCNPhysicsBody bodyWithType:SCNPhysicsBodyTypeKinematic shape:[SCNPhysicsShape shapeWithGeometry:[SCNSphere sphereWithRadius:4] options:nil]];
    self.ballNode = ballNode;
    
    [self  createBox];
    
    SCNCamera *camera = [SCNCamera camera];
    SCNNode *cameraNode = [SCNNode node];
    cameraNode.camera = camera;
    cameraNode.position = SCNVector3Make(0, 10, 80);
    [scene.rootNode addChildNode:cameraNode];
    self.cameraNode = cameraNode;
    
    // create and add a light to the scene
    SCNNode *lightNode = [SCNNode node];
    lightNode.light = [SCNLight light];
    lightNode.light.type = SCNLightTypeOmni;
    lightNode.position = SCNVector3Make(0, 20, 50);
    [scene.rootNode addChildNode:lightNode];
    self.lightNode = lightNode;
    
    //     create and add an ambient light to the scene
    SCNNode *ambientLightNode = [SCNNode node];
    ambientLightNode.light = [SCNLight light];
    ambientLightNode.light.type = SCNLightTypeAmbient;
    ambientLightNode.light.color = [UIColor darkGrayColor];
    [scene.rootNode addChildNode:ambientLightNode];
    
    
    SCNView *scnView = (SCNView *)self.view;
    // set the scene to the view
    scnView.scene = scene;
    
    // allows the user to manipulate the camera
    scnView.allowsCameraControl = YES;
    
    // show statistics such as fps and timing information
    scnView.showsStatistics = YES;
    
    // configure the view
    scnView.backgroundColor = [UIColor blackColor];
    
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap:)];
    NSMutableArray *gestureRecognizers = [NSMutableArray array];
    [gestureRecognizers addObject:tapGesture];
    //    [gestureRecognizers addObjectsFromArray:scnView.gestureRecognizers];
    scnView.gestureRecognizers = gestureRecognizers;
    
    NSTimer *timer =  [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(changePosition) userInfo:nil repeats:YES];
    self.timer = timer;
    NSRunLoop *runloop = [NSRunLoop mainRunLoop];
    [runloop addTimer:timer forMode:NSDefaultRunLoopMode];
    
    [self createBtn];
    
    self.scoreLabel.text = @"0";
    [self createCollision];
}

- (void)createBtn{
    UIButton *stopBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [stopBtn setTitle:@"stop" forState:UIControlStateNormal];
    [stopBtn setTitle:@"start" forState:UIControlStateSelected];
    [stopBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [stopBtn setBackgroundColor:[UIColor darkGrayColor]];
    [self.view addSubview:stopBtn];
    [stopBtn addTarget:self action:@selector(stop:) forControlEvents:UIControlEventTouchUpInside];
    stopBtn.frame = CGRectMake(100, 100, 90, 40);
    
    UIButton *restartBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [restartBtn setTitle:@"restart" forState:UIControlStateNormal];
    [restartBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [restartBtn setBackgroundColor:[UIColor darkGrayColor]];
    [self.view addSubview:restartBtn];
    [restartBtn addTarget:self action:@selector(restart) forControlEvents:UIControlEventTouchUpInside];
    
    restartBtn.frame = CGRectMake(200, 100, 90, 40);
}

- (void)restart{
    [self.scene.rootNode removeFromParentNode];
    [self createNode];
    self.failLabel.hidden = YES;
}

- (void)stop:(UIButton *)btn{
    btn.selected = !btn.isSelected;
    [self.scene setPaused:btn.selected];
    
    if (btn.isSelected) {
        [self.timer setFireDate:[NSDate distantFuture]];
//        [self.timer invalidate];
    }else{
//        [[NSRunLoop mainRunLoop] runUntilDate:[NSDate distantPast]];
        [self.timer setFireDate:[NSDate distantPast]];
    }
    
}

- (void)changePosition{

    NSArray<SCNNode *> *array = self.scene.rootNode.childNodes;
    CGFloat maxY = -MAXFLOAT;
    CGFloat minY = 0;
    SCNNode *sourceNode;
    SCNNode *toNode;
    SCNNode *midNode;
    
    for (SCNNode *boxNode in array) {
        if ([boxNode.name isEqualToString:@"box"]) {
            if (maxY <= boxNode.position.y) {
                maxY = boxNode.position.y;
                sourceNode = boxNode;
            }
        }
    }
    
    for (SCNNode *boxNode in array) {
        if ([boxNode.name isEqualToString:@"box"]) {
            if (minY >= boxNode.position.y){
                minY = boxNode.position.y;
                toNode = boxNode;
            }
        }
    }
    
    for (SCNNode *boxNode in array) {
        if ([boxNode.name isEqualToString:@"box"]) {
            if (![boxNode isEqual:sourceNode] && ![boxNode isEqual:toNode]) {
                midNode = boxNode;
            }
        }
    }
    
    SCNVector3 position = toNode.position;
    SCNVector3 currentPosition = toNode.position;
    
    SCNVector3 midPosition = midNode.position;
    
    SCNVector3 cameraPosition = self.cameraNode.position;
    SCNVector3 currentCameraPosition = self.cameraNode.position;
    
    SCNVector3 currentLightPosition = self.lightNode.position;
    SCNVector3 lightPosition = self.lightNode.position;
    
   
    do {
        if (position.x == midPosition.x && position.z == midPosition.z) {
            position = currentPosition;
            cameraPosition = currentCameraPosition;
            lightPosition = currentLightPosition;
        }
        switch (arc4random() % 3) {
            case 0:
                position.x += 16;
                cameraPosition.x += 16;
                lightPosition.x += 16;
                break;
            case 1:
                position.x -= 16;
                cameraPosition.x -= 16;
                lightPosition.x -= 16;
                break;
            case 2:
                position.z += 16;
                cameraPosition.z += 16;
                lightPosition.z += 16;
                break;
            default:
                break;
        }
        
    } while (position.x == midPosition.x && position.z == midPosition.z);
    
             
    position.y -= 6;
    cameraPosition.y -= 6;
    lightPosition.y -= 6;
    
    SCNAction *move = [SCNAction moveTo:position duration:0.9];
    SCNAction *spin = [SCNAction rotateByAngle:M_PI * 2 aroundAxis:SCNVector3Make(0, 2, 0) duration:0.9];
    SCNAction *action = [SCNAction group:@[move,spin]];
    [sourceNode runAction:[SCNAction repeatAction:action count:1]];
    
    SCNVector3 ballPosition = _ballNode.position;
    ballPosition.y -= 6;
    if (!SCNVector3EqualToVector3(_boxNode1.position, ballPosition) && !SCNVector3EqualToVector3(_boxNode2.position, ballPosition) && !SCNVector3EqualToVector3(_boxNode3.position, ballPosition)) {
        SCNVector3 endPosition = ballPosition;
        endPosition.y -= 200;
        [_ballNode runAction:[SCNAction repeatAction:[SCNAction moveTo:endPosition duration:1] count:1]];
        [self.scene setPaused:NO];
        [self.timer invalidate];
        self.failLabel.hidden = NO;
    }
    
    
    
    [self.cameraNode runAction:[SCNAction repeatAction:[SCNAction moveTo:cameraPosition duration:1] count:1]];
    
    [self.lightNode runAction:[SCNAction repeatAction:[SCNAction moveTo:lightPosition duration:1] count:1]];
}

- (void)createBox{
    SCNVector3 position1 = SCNVector3Make(0, 0, 0);
    SCNBox *box1 = [SCNBox boxWithWidth:15 height:4 length:15 chamferRadius:0];
    SCNNode *boxNode1 = [SCNNode nodeWithGeometry:box1];
    boxNode1.name = @"box";
    [self.scene.rootNode addChildNode:boxNode1];
    boxNode1.position = position1;
    boxNode1.physicsBody = [SCNPhysicsBody bodyWithType:SCNPhysicsBodyTypeKinematic shape:[SCNPhysicsShape shapeWithNode:boxNode1 options:nil]];
    boxNode1.physicsBody.collisionBitMask = CollisionDetectionMaskBox1;
    self.boxNode1 = boxNode1;
    
    boxNode1.geometry.firstMaterial.diffuse.contents = [UIColor colorWithRed:arc4random()%256 / 256.0 green:arc4random()%256 / 256.0 blue:arc4random()%256 / 256.0 alpha:1];
    
    SCNVector3 position2 = SCNVector3Make(0, 6, -16);
    SCNBox *box2 = [SCNBox boxWithWidth:15 height:4 length:15 chamferRadius:0];
    SCNNode *boxNode2 = [SCNNode nodeWithGeometry:box2];
    boxNode2.name = @"box";
    [self.scene.rootNode addChildNode:boxNode2];
    boxNode2.position = position2;
    boxNode2.physicsBody = [SCNPhysicsBody bodyWithType:SCNPhysicsBodyTypeKinematic shape:[SCNPhysicsShape shapeWithNode:boxNode2 options:nil]];
    boxNode2.physicsBody.collisionBitMask = CollisionDetectionMaskBox2;
    self.boxNode2 = boxNode2;
    boxNode2.geometry.firstMaterial.diffuse.contents = [UIColor colorWithRed:arc4random()%256 / 256.0 green:arc4random()%256 / 256.0 blue:arc4random()%256 / 256.0 alpha:1];
    
    SCNVector3 position3 = SCNVector3Make(0, -6, 16);
    SCNBox *box3 = [SCNBox boxWithWidth:15 height:4 length:15 chamferRadius:0];
    SCNNode *boxNode3 = [SCNNode nodeWithGeometry:box3];
    boxNode3.name = @"box";
    boxNode3.position = position3;
    [self.scene.rootNode addChildNode:boxNode3];
    boxNode3.position = position3;
    boxNode3.physicsBody = [SCNPhysicsBody bodyWithType:SCNPhysicsBodyTypeKinematic shape:[SCNPhysicsShape shapeWithNode:boxNode3 options:nil]];
    boxNode3.physicsBody.collisionBitMask = CollisionDetectionMaskBox3;
    self.boxNode3 = boxNode3;
    boxNode3.geometry.firstMaterial.diffuse.contents = [UIColor colorWithRed:arc4random()%256 / 256.0 green:arc4random()%256 / 256.0 blue:arc4random()%256 / 256.0 alpha:1];
    
}

-(void)createCollision{
    
    //    设置碰撞事件
    _ballNode.physicsBody.collisionBitMask = CollisionDetectionMaskBox1 | CollisionDetectionMaskBox2 | CollisionDetectionMaskBox3;
    _ballNode.physicsBody.contactTestBitMask = CollisionDetectionMaskBox1 | CollisionDetectionMaskBox2 | CollisionDetectionMaskBox3;
    
    
    _boxNode1.physicsBody.collisionBitMask = CollisionDetectionMaskBall;
    _boxNode1.physicsBody.contactTestBitMask = CollisionDetectionMaskBall;
    
    _boxNode2.physicsBody.collisionBitMask = CollisionDetectionMaskBall;
    _boxNode2.physicsBody.contactTestBitMask = CollisionDetectionMaskBall;
    
    _boxNode3.physicsBody.collisionBitMask = CollisionDetectionMaskBall;
    _boxNode3.physicsBody.contactTestBitMask = CollisionDetectionMaskBall;
    
    //    设置碰撞代理
    self.scene.physicsWorld.contactDelegate = self;
}


- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [self.timer setFireDate:[NSDate distantFuture]];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self.timer setFireDate:[NSDate distantPast]];
}

- (void)handleTap:(UITapGestureRecognizer *)tap{
    
    
    CGPoint p = [tap locationInView:self.view];
    CGRect leftRect = CGRectMake(0, 200, 100, 400);
    
    CGRect rightRect = CGRectMake(self.view.bounds.size.width - 100, 200, 100, 400);
    
    CGRect bottomRect = CGRectMake(100, 400, self.view.bounds.size.width - 200, 200);
    
    SCNVector3 position = self.ballNode.position;
    
    if (CGRectContainsPoint(leftRect, p)) {
        position.x -= 16;
    }else if(CGRectContainsPoint(rightRect, p)){
        position.x += 16;
    }else if(CGRectContainsPoint(bottomRect, p)){
        position.z += 16;
    }else{
        position.z -= 16;
    }
    position.y -= 6;
    
     [_ballNode runAction:[SCNAction repeatAction:[SCNAction moveTo:position duration:0.2] count:1]];
    position.y -= 6;
    if (!SCNVector3EqualToVector3(_boxNode1.position, position) && !SCNVector3EqualToVector3(_boxNode2.position, position) && !SCNVector3EqualToVector3(_boxNode3.position, position)) {
        SCNVector3 endPosition = position;
        endPosition.y -= 200;
        [_ballNode runAction:[SCNAction repeatAction:[SCNAction moveTo:endPosition duration:1] count:1]];
        [self.scene setPaused:NO];
        [self.timer invalidate];
        self.failLabel.hidden = NO;
    }else{
        NSInteger score = [self.scoreLabel.text integerValue];
        self.scoreLabel.text = [NSString stringWithFormat:@"%ld",score+10];
    }
}

#pragma mark - SCNPhysicsContactDelegate
-(void)physicsWorld:(SCNPhysicsWorld *)world didBeginContact:(SCNPhysicsContact *)contact{
}

-(void)physicsWorld:(SCNPhysicsWorld *)world didUpdateContact:(SCNPhysicsContact *)contact{
}

-(void)physicsWorld:(SCNPhysicsWorld *)world didEndContact:(SCNPhysicsContact *)contact{

    SCNVector3 contactPoint  = contact.contactPoint;

    [SCNTransaction begin];
    [SCNTransaction setAnimationDuration:1];

    // on completion
    [SCNTransaction setCompletionBlock:^{
        [SCNTransaction begin];
        [SCNTransaction setAnimationDuration:0.5];
        
//        [self.scene setPaused:NO];
//        [self.timer invalidate];
        
        [SCNTransaction commit];
    }];

    SCNVector3 endPosition = contactPoint;
    endPosition.y -= 200;

//    [_ballNode runAction:[SCNAction repeatAction:[SCNAction moveTo:endPosition duration:1] count:1]];
    
    [SCNTransaction commit];
}

@end
